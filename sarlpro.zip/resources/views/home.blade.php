<!-- resources/views/home.blade.php -->

@extends('layout')

@section('title', 'Homessssss Page')

@section('content')
    <h1>Welcome to the Home Page</h1>
    <p>This is the content of the home page.</p>
@endsection
